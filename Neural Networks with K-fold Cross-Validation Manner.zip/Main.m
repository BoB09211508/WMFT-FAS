clc, clear
% Benchmark dataset contains 150 instances and 4 features (three classes)
load test.mat; % Matlab also provides this dataset (load fisheriris.mat)
% Call features & labels 
feat=f; label=l;Hidden=20;
%---Input------------------------------------------------------------------
% feat:      features (intances x features)
% label:     labelling (labels x 1)
% kfold:     Number of cross-validation
% Hiddens:   Hidden layers (Hidden layers up to three, such as [10,10,10]) 
% Maxepochs: Maximum number of Epochs
%---Output-----------------------------------------------------------------
% A struct that contains three results as follows:
% fold: Accuracy for each fold
% acc:  Average accuracy over k-folds
% con:  Confusion matrix
%--------------------------------------------------------------------------
% 
% %(1) Perform neural network (NN)
% kfold=16; Hiddens=Hidden; Maxepochs=5000;
% NN=jNN(feat,label,kfold,Hiddens,Maxepochs);
% 
% % (2) Perform neural network with multiple layers (MNN)
% kfold=16; Hiddens=[Hidden,Hidden,Hidden]; Maxepochs=5000;
% MNN=jNN(feat,label,kfold,Hiddens,Maxepochs);
% 
%(3) Perform feed-foward neural network (FFNN)
kfold=16; Hiddens=Hidden; Maxepochs=5000;
FFNN=jFFNN(feat,label,kfold,Hiddens,Maxepochs);
% 
% % (4) Perform cascade foward neural network (CFNN)
% kfold=16; Hiddens=Hidden; Maxepochs=5000;
% CFNN=jCFNN(feat,label,kfold,Hiddens,Maxepochs);
% 
% %(5) Perform recurrent neural network (RNN)
% kfold=16; Hiddens=Hidden; Maxepochs=5000;
% RNN=jRNN(feat,label,kfold,Hiddens,Maxepochs);
% 
% % (6) Perform generalized regression neural network (GRNN)
% kfold=16; nSpread=1; % Number of spread in GRNN
% GRNN=jGRNN(feat,label,kfold,nSpread);
% 
% % (7) Perform probabilistic neural network (PNN)
% kfold=16; nSpread=0.1; % Number of spread in PNN
% PNN=jPNN(feat,label,kfold,nSpread);





